<?php
// Text
$_['text_title'] = 'Pay by Cryptocurrency';
$_['user_paid'] = 'User has paid';