<?php
// Text
$_['text_title'] = '使用虛擬貨幣付款';
$_['user_paid'] = '使用者已付款';